================
pythag-dist-calc
================
Determines the distance of two points on an [x]d plane.
